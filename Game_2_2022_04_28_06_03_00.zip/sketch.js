let ball;
let paddle;
let bricks = [];
let level = [];
let w, h;
let gameStarted = false;
let gameInfo = false;
let gameOver = false;
let gameWon = false;
let score = 0;
let lives = 3;
let ww = window.innerWidth;
let wh = window.innerHeight;
let scale;
var img;
var ast;
var impact;
var sun;
 
function preload()
{
  // load image
  img = loadImage("assets/SpaceBackdrop1920x1080.jpg");
  ast = loadImage("assets/image-removebg-preview (1).png");
  sun = loadImage("assets/sun1.png");
  soundFormats('mp3');
  impact = loadSound('assets/impactsound.mp3');
}


function setup() {
  scale = (1920 / ww / (1080 / wh)) * 0.5;
  createCanvas(ww, wh);
  createBricks();
  ball = new Ball(ww / 2, 0.91*wh);
  paddle = new Paddle(ww / 2, 0.925*wh, ww*0.075, wh*0.0111);
}

function keyPressed() {
  if (keyCode === "") {
    gameInfo = false;
    gameOver=false;
    gameStarted=false;
    gameWon=false
  }
  
  if (keyCode === ENTER) {
    gameInfo = true;
    gameOver = false;
    gameStarted = false;
    gameWon = false;
    ball.reset();
    paddle.reset();
    createBricks(1);
    score = 0;
    lives = 3;
  }

  if (key === " ") {
    gameStarted = true;
    gameInfo = false;
    gameWon = false;
    gameOver = false;
  }
  
  if (key == "1") {
    createBricks(1);
  } else if (key == "2") {
    createBricks(2);
  }
}

function draw() {
  const bkg = color("rgb(0,0,0)");
  background(red(bkg) / 2, green(bkg) / 2, blue(bkg) / 2);
  
  background(img);

  for (let brick of bricks) {
    brick.render();
  }
  ball.render();
  paddle.render();
  ball.edges();
  ball.end();
  ball.won();

  if (gameInfo && !gameStarted && !gameOver && !gameWon) {
    textAlign(CENTER, CENTER);
    textSize(20);
    fill("LightGoldenRodYellow");
    strokeWeight(3);
    stroke(0);
    text("Press Space to start", ww / 2, wh / 2);
    ball.pos.x = paddle.pos.x;
  }

  //ball.update();

  if (gameStarted && !gameInfo && !gameOver && !gameWon) {
    paddle.update();
    ball.update();
    ball.bounce(paddle);

    let ABBrick = false;
    for (let i = bricks.length - 1; i >= 0; i--) {
      let brick = bricks[i];
      if (ball.colliding(brick)) {
        if (ABBrick === false) {
          ball.bounceOff(brick);
          ABBrick = true;
        }
        score += brick.points;
        bricks.splice(i, 1);
      }
    }
  }

  
  if (gameOver && !gameStarted && !gameInfo && !gameWon) {
    fill("darkMagenta");
    textAlign(CENTER, CENTER);
    strokeWeight(5);
    stroke("firebrick");
    textSize(50);
    text("GAME OVER!!", ww / 2, wh / 2);
    fill("Khaki");
    textSize(20);
    text("press enter to play again!", ww / 2, 0.575*wh);
  }

  if (gameWon && !gameOver && !gameStarted && !gameInfo) {
    textAlign(CENTER, CENTER);
    textSize(70);
    stroke("Chartreuse");
    strokeWeight(6);
    fill("MediumSpringGreen");
    text("YOU WON!!", ww / 2, 0.5*wh);
    stroke(0);
    strokeWeight(3);
    text("YOU WON!!", ww / 2, 0.5*wh);
    fill("cyan");
    stroke(0);
    textSize(50);
    text("Congratulations!!!", ww / 2, 0.425*wh);
    fill("Khaki");
    text("press enter to play again!", ww / 2, 0.575*wh);
    level = (2);
  }
  
  fill("#FFFFFF");
  textStyle(BOLD);
  textAlign(CENTER);
  noStroke();
  textFont("Arial");
  textSize(30);
  text("Score: " + score, ww * 0.8, wh * 0.03);
  
  fill("#FFFFFF");
  textStyle(BOLD);
  textAlign(CENTER);
  noStroke();
  textFont("Arial");
  textSize(30);
  text("Lives: " + lives, ww * 0.2, wh * 0.03);
}

function createBricks(level) {
  if (level === 1) {
    bricks.splice(0);
    for (let i = 0; i < 10; i++) {
      for (let j = 0; j < 5; j++) {
        w = ww / 21;
        h = 0.05*wh;
        bricks.push(
          new Brick(i * 2*w + 1.5*w, j * 2*h + h + 0.1*wh, w, h, 5 - j)
        );
      }
    }
  }
  if (level === 2) {
    bricks.splice(0);
    for (let i = 0; i < 20; i++) {
      for (let j= 0; j < 10; j++) {
        w = ww/41;
        h = 1/2*wh*1/((ww/40)/scale);
        bricks.push(
          new Brick(i* 2*w +1.5*w, j*2*h + h +0.1*wh, w, h, 20 -j)
        );
      }
    }
  }
}
