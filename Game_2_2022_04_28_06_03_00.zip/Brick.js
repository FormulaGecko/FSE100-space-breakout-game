class Brick extends Paddle {
  constructor(x, y, w, h, points) {
    super(x, y ,w, h);
    this.points = points;
    }
  
  render() {
    push();
    strokeWeight(2);
    if (this.points === 1) {
      stroke("gray");
      fill("gray");
    } else if (this.points === 2) {
      stroke("gray");
      fill("gray");
    } else if (this.points === 3) {
      stroke("gray");
      fill("gray");
    } else if (this.points === 4) {
      stroke("gray");
      fill("gray");
    } else if (this.points === 5) {
      stroke("gray");
      fill("gray");
    } else if (this.points === 6) {
      stroke("gray");
      fill("gray");
    } else if (this.points === 7) {
      stroke("gray");
      fill("gray");
    }
    rectMode(CENTER);
    rect(this.pos.x, this.pos.y, this.width*0.9, this.height*0.9);
    textAlign(CENTER, CENTER);
    textSize(15);
    noStroke();
    fill(0);
    text(this.points, this.pos.x, this.pos.y);
    imageMode(CENTER);
    image(ast,this.pos.x, this.pos.y, this.width*1.5, this.height*1.5);
    pop();   
  }
}